# Android Security Toolkit — Module Technical Reference

> **Mục đích:** Tài liệu này giải thích logic kỹ thuật của từng module trong ứng dụng Android Security Toolkit, dành cho mục đích học tập và báo cáo Lab bảo mật.

---

## Tổng quan kiến trúc (Architecture Overview)

```
com.sectoolkit/
├── model/          # Pure data classes (AppInfo, ExportedComponent, IntentExtra, ClipboardEntry)
├── recon/          # Module 1 — ExportedComponentScanner
├── intent/         # Module 2 — IntentDispatcher
├── provider/       # Module 3 — ContentProviderAuditor
├── clipboard/      # Module 4 — ClipboardMonitorService
└── ui/             # Fragments, Adapters, MainActivity
```

**Design Pattern:** Singleton cho tất cả các lớp core logic, đảm bảo mỗi module chỉ có một instance duy nhất trong suốt vòng đời ứng dụng. UI layer hoàn toàn tách biệt khỏi business logic theo nguyên tắc **Separation of Concerns**.

---

## Module 1 — Attack Surface Reconnaissance

### Class: `ExportedComponentScanner`

#### Mục tiêu kỹ thuật
Xác định **Attack Surface** (bề mặt tấn công) của một ứng dụng Android bằng cách liệt kê tất cả các component được export ra bên ngoài.

#### API Android được sử dụng
| API | Mục đích |
|-----|----------|
| `PackageManager.getInstalledPackages()` | Lấy danh sách tất cả app đã cài đặt |
| `PackageManager.GET_ACTIVITIES` | Flag để lấy thông tin Activities |
| `PackageManager.GET_SERVICES` | Flag để lấy thông tin Services |
| `PackageManager.GET_RECEIVERS` | Flag để lấy thông tin BroadcastReceivers |
| `PackageManager.GET_PROVIDERS` | Flag để lấy thông tin ContentProviders |
| `ActivityInfo.exported` | Boolean field xác định component có exported không |

#### Logic hoạt động

```
getAllInstalledApps()
  └─► PackageManager.getInstalledPackages(GET_ACTIVITIES | GET_SERVICES | GET_RECEIVERS | GET_PROVIDERS)
        └─► Duyệt mảng PackageInfo[]
              └─► countExportedComponents(pkg)
                    ├─► pkg.activities[] → kiểm tra ActivityInfo.exported
                    ├─► pkg.services[]   → kiểm tra ServiceInfo.exported
                    ├─► pkg.receivers[]  → kiểm tra ActivityInfo.exported
                    └─► pkg.providers[]  → kiểm tra ProviderInfo.exported

getExportedComponents(packageName)
  └─► PackageManager.getPackageInfo(packageName, flags)
        └─► Duyệt từng array component
              └─► Nếu info.exported == true:
                    ├─► Ghi nhận tên class
                    ├─► Ghi nhận loại component (ACTIVITY/SERVICE/RECEIVER/PROVIDER)
                    └─► Kiểm tra info.permission != null → phân loại PROTECTED / NO PERMISSION
```

#### Ý nghĩa bảo mật
- **Component có `exported=true` nhưng không có `permission`**: Đây là lỗ hổng nghiêm trọng. Bất kỳ ứng dụng nào trên thiết bị đều có thể khởi động component này mà không cần xác thực.
- **Ví dụ tấn công thực tế**: Một `LoginActivity` được export mà không có permission cho phép attacker bypass màn hình đăng nhập bằng cách gọi trực tiếp Activity sau màn hình login.
- **Permission `QUERY_ALL_PACKAGES`**: Bắt buộc từ Android 11 (API 30) để có thể query thông tin về tất cả package. Không có permission này, hệ thống sẽ chỉ trả về danh sách rút gọn.

---

## Module 2 — Intent Exploitation Lab

### Class: `IntentDispatcher`

#### Mục tiêu kỹ thuật
Mô phỏng kỹ thuật **Intent Spoofing** — gửi Intent được tạo thủ công đến một component cụ thể, bypass cơ chế Intent Filter thông thường của Android.

#### API Android được sử dụng
| API | Mục đích |
|-----|----------|
| `ComponentName(packageName, className)` | Chỉ định đích đến chính xác, bỏ qua Intent resolution |
| `Intent.setComponent()` | Áp dụng ComponentName vào Intent |
| `Context.startActivity()` | Dispatch Intent đến một Activity |
| `Context.startService()` | Dispatch Intent đến một Service |
| `Context.sendBroadcast()` | Broadcast Intent đến các Receivers |
| `Intent.putExtra()` | Đính kèm dữ liệu vào Intent |

#### Logic hoạt động

```
dispatch(packageName, className, action, extras, mode)
  └─► buildIntent()
        ├─► Nếu packageName + className != null:
        │     └─► intent.setComponent(new ComponentName(pkg, cls))
        │           [Explicit Intent — bypass Intent Filter]
        ├─► Nếu chỉ có packageName:
        │     └─► intent.setPackage(pkg)
        ├─► Nếu có action:
        │     └─► intent.setAction(action)
        └─► Với mỗi IntentExtra:
              └─► applyExtra(intent, extra)
                    └─► Switch(extra.type):
                          STRING  → putExtra(key, String)
                          INT     → putExtra(key, Integer.parseInt(value))
                          BOOLEAN → putExtra(key, Boolean.parseBoolean(value))
                          LONG    → putExtra(key, Long.parseLong(value))
                          FLOAT   → putExtra(key, Float.parseFloat(value))

  └─► Switch(mode):
        ACTIVITY  → context.startActivity(intent)
        SERVICE   → context.startService(intent)
        BROADCAST → context.sendBroadcast(intent)
```

#### Ý nghĩa bảo mật

**Tại sao `ComponentName` nguy hiểm?**

Thông thường, một Implicit Intent (Intent chỉ có action, không có component cụ thể) sẽ đi qua hệ thống Intent Resolution của Android, hệ thống sẽ tìm component phù hợp dựa trên `<intent-filter>`. Tuy nhiên, khi dùng `ComponentName` để tạo một **Explicit Intent**:

1. Android bỏ qua hoàn toàn bước Intent Resolution
2. Intent được gửi trực tiếp đến đúng component đã chỉ định
3. Không cần component đích phải khai báo `<intent-filter>` tương ứng

**Kịch bản tấn công điển hình:**
- Target app có `com.bank.app.DashboardActivity` với `exported=true` nhưng không có `permission`
- Attacker dùng tool này gửi Explicit Intent đến `DashboardActivity` với extra `isLoggedIn=true`
- Kết quả: Bypass màn hình đăng nhập hoàn toàn

---

## Module 3 — Content Provider Auditor

### Class: `ContentProviderAuditor`

#### Mục tiêu kỹ thuật
Khai thác **Insecure Content Provider** — truy xuất dữ liệu thô từ database SQLite của ứng dụng khác thông qua `ContentResolver`, không cần quyền truy cập đặc biệt nếu Provider không được bảo vệ.

#### API Android được sử dụng
| API | Mục đích |
|-----|----------|
| `ContentResolver.query(uri, null, null, null, null)` | Query tất cả rows và columns từ một URI |
| `Uri.parse(uriString)` | Parse chuỗi thành Android Uri object |
| `Cursor.getColumnNames()` | Lấy danh sách tên cột |
| `Cursor.moveToNext()` | Duyệt từng row trong kết quả |
| `Cursor.getString(columnIndex)` | Đọc giá trị một ô dữ liệu |

#### Logic hoạt động

```
query(uriString)
  ├─► Validate: uriString không null/empty
  ├─► Uri.parse(uriString) → Uri object
  └─► ContentResolver.query(uri, null, null, null, null)
        │   [null projection = SELECT *]
        │   [null selection = WHERE clause rỗng]
        │   [null sortOrder = không ORDER BY]
        └─► Cursor result
              ├─► Nếu cursor == null → Provider không tồn tại hoặc bị từ chối
              ├─► cursor.getColumnNames() → List<String> columns
              └─► while(cursor.moveToNext()):
                    └─► Với mỗi column:
                          cursor.getString(i) → value
                          Thêm vào Map<String, String> row
              └─► Trả về QueryResult(columns, rows)

Exception Handling:
  SecurityException       → Provider yêu cầu permission, bị từ chối
  IllegalArgumentException → URI format không hợp lệ
  Exception               → Lỗi không xác định
```

#### Ý nghĩa bảo mật

**Cấu trúc URI Content Provider:**
```
content://[authority]/[path]/[id]
  │              │        │     └─ Record ID cụ thể (tùy chọn)
  │              │        └─ Đường dẫn đến bảng dữ liệu
  │              └─ Package hoặc authority string của provider
  └─ Scheme bắt buộc
```

**Ví dụ URI nguy hiểm thực tế:**
```
content://com.android.contacts/contacts          → Danh bạ
content://sms                                    → Tin nhắn SMS
content://com.vulnerable.app/users              → User database của app lỗ hổng
content://com.vulnerable.app/credentials        → Credentials bị lộ
```

**Điều kiện để tấn công thành công:**
- Provider có `android:exported="true"` trong Manifest
- Provider không khai báo `android:readPermission` hoặc `android:writePermission`
- Provider không có `android:permission`

Khi đủ điều kiện này, bất kỳ app nào trên cùng thiết bị đều có thể đọc toàn bộ database SQLite của app nạn nhân.

---

## Module 4 — Data Leakage Monitor (Clipboard)

### Class: `ClipboardMonitorService`

#### Mục tiêu kỹ thuật
Triển khai kỹ thuật **Sensitive Data Exposure qua Clipboard** — đăng ký lắng nghe sự kiện clipboard để ghi lại bất kỳ văn bản nào người dùng sao chép, bao gồm mật khẩu, mã OTP, số thẻ tín dụng.

#### API Android được sử dụng
| API | Mục đích |
|-----|----------|
| `ClipboardManager` | System service quản lý clipboard |
| `ClipboardManager.addPrimaryClipChangedListener()` | Đăng ký callback khi clipboard thay đổi |
| `ClipboardManager.getPrimaryClip()` | Lấy nội dung clipboard hiện tại |
| `ClipData.Item.getText()` | Đọc văn bản từ clipboard item |
| `Service.startForeground()` | Chạy service ở foreground với notification |
| `NotificationChannel` | Kênh notification bắt buộc từ Android 8+ |

#### Logic hoạt động

```
ClipboardMonitorService extends Service
  │
  onCreate()
    ├─► getSystemService(CLIPBOARD_SERVICE) → ClipboardManager
    ├─► clipboardManager.addPrimaryClipChangedListener(clipListener)
    └─► startForeground(NOTIFICATION_ID, buildNotification())
          [Bắt buộc để service không bị kill bởi OS]

  OnPrimaryClipChangedListener.onPrimaryClipChanged()  ← [TRIGGER]
    ├─► clipboardManager.hasPrimaryClip() → kiểm tra có dữ liệu không
    ├─► getPrimaryClip().getItemAt(0) → lấy item đầu tiên
    ├─► item.getText().toString() → chuỗi văn bản
    ├─► Tạo ClipboardEntry(text, System.currentTimeMillis())
    ├─► capturedEntries.add(0, entry) → thêm vào đầu list (mới nhất trước)
    └─► eventListener.onNewClipboardEntry(entry) → notify UI

  onDestroy()
    └─► clipboardManager.removePrimaryClipChangedListener(clipListener)
          [Dọn dẹp listener, tránh memory leak]
```

#### Ý nghĩa bảo mật

**Tại sao đây là lỗ hổng nghiêm trọng?**

Trước Android 12 (API 31), bất kỳ ứng dụng nào đang chạy ở background đều có thể đọc clipboard mà không cần quyền đặc biệt. Đây là vector tấn công phổ biến để:

| Loại dữ liệu nhạy cảm | Kịch bản bị lộ |
|------------------------|----------------|
| Mật khẩu | Copy từ password manager |
| Mã OTP / 2FA | Copy từ SMS hoặc app authenticator |
| Số thẻ tín dụng | Copy khi nhập thông tin thanh toán |
| Private key / Seed phrase | Copy khi setup ví crypto |
| Token xác thực | Copy API key hoặc bearer token |

**Biện pháp phòng thủ (cho developer):**
- Sử dụng `ClipboardManager.clearPrimaryClip()` ngay sau khi paste
- Implement custom keyboard với `TYPE_TEXT_FLAG_NO_SUGGESTIONS`
- Sử dụng `AutofillService` thay vì clipboard cho thông tin nhạy cảm
- Xóa clipboard sau một khoảng thời gian nhất định (time-based clearing)

**Thay đổi từ Android 12:**
Từ Android 12 (API 31), khi một app ở background đọc clipboard, hệ thống sẽ hiển thị toast thông báo cho người dùng biết. Điều này làm giảm nhưng không loại bỏ hoàn toàn nguy cơ.

---

## Bảng tóm tắt kỹ thuật

| Module | Class chính | Android API cốt lõi | Loại lỗ hổng | Mức độ nguy hiểm |
|--------|-------------|---------------------|--------------|-------------------|
| Recon | `ExportedComponentScanner` | `PackageManager` | Exposed Attack Surface | 🟡 Medium |
| Intent Lab | `IntentDispatcher` | `ComponentName`, `Intent` | Intent Spoofing | 🔴 High |
| Provider | `ContentProviderAuditor` | `ContentResolver.query()` | Insecure Data Storage | 🔴 High |
| Clipboard | `ClipboardMonitorService` | `ClipboardManager` | Sensitive Data Exposure | 🔴 High |

---

## Hướng dẫn sử dụng cho Lab

### Module 1 — Recon
1. Mở tab **Recon**
2. Chờ danh sách apps được load (chip màu vàng = có exported components)
3. Tap vào app cần phân tích
4. Xem danh sách components: chip đỏ "NO PERMISSION" = mục tiêu tiềm năng

### Module 2 — Intent Lab
1. Mở tab **Intent Lab**
2. Nhập Package Name từ kết quả Recon (vd: `com.target.app`)
3. Nhập Class Name của component đã phát hiện (vd: `com.target.app.AdminActivity`)
4. Chọn mode: **Activity** / **Service** / **Broadcast**
5. Thêm Extras nếu cần (vd: `isAdmin=true`)
6. Nhấn **DISPATCH INTENT**

### Module 3 — Provider Auditor
1. Mở tab **Provider**
2. Nhập URI của provider từ kết quả Recon (vd: `content://com.target.app.provider/users`)
3. Nhấn **QUERY**
4. Kết quả hiển thị dạng bảng với tất cả rows và columns

### Module 4 — Clipboard Monitor
1. Mở tab **Clipboard**
2. Bật toggle **Monitor Status**
3. Thực hiện copy bất kỳ văn bản nào trên thiết bị
4. Quay lại app để xem dữ liệu đã được capture với timestamp

---

## Disclaimer

> Tool này được phát triển **chỉ cho mục đích học tập và nghiên cứu bảo mật**. Việc sử dụng tool này để tấn công hệ thống hoặc ứng dụng mà bạn không có quyền kiểm tra là **hành vi vi phạm pháp luật**. Chỉ sử dụng trên thiết bị và ứng dụng của chính bạn hoặc trong môi trường lab được phép.
