package com.sectoolkit.ui.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.sectoolkit.R;
import com.sectoolkit.model.AppInfo;
import com.sectoolkit.recon.ExportedComponentScanner;
import com.sectoolkit.ui.adapters.AppListAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class ReconFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView statusText;
    private TextInputEditText searchField;
    private AppListAdapter adapter;
    private List<AppInfo> allApps = new ArrayList<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_recon, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recycler_apps);
        progressBar = view.findViewById(R.id.progress_bar);
        statusText = view.findViewById(R.id.status_text);
        searchField = view.findViewById(R.id.search_field);

        adapter = new AppListAdapter(new ArrayList<>(), this::onAppSelected);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        searchField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                filterApps(s.toString());
            }
        });

        loadApps();
    }

    private void loadApps() {
        progressBar.setVisibility(View.VISIBLE);
        statusText.setText("Scanning installed packages...");
        recyclerView.setVisibility(View.GONE);

        executor.execute(() -> {
            List<AppInfo> apps = ExportedComponentScanner.getInstance(requireContext()).getAllInstalledApps();
            mainHandler.post(() -> {
                allApps = apps;
                progressBar.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
                statusText.setText(apps.size() + " apps found");
                adapter.updateData(apps);
            });
        });
    }

    private void filterApps(String query) {
        if (query.isEmpty()) {
            adapter.updateData(allApps);
            return;
        }
        String lower = query.toLowerCase();
        List<AppInfo> filtered = allApps.stream()
                .filter(a -> a.getAppName().toLowerCase().contains(lower) ||
                             a.getPackageName().toLowerCase().contains(lower))
                .collect(Collectors.toList());
        adapter.updateData(filtered);
    }

    private void onAppSelected(AppInfo appInfo) {
        ComponentDetailFragment detail = ComponentDetailFragment.newInstance(
                appInfo.getPackageName(), appInfo.getAppName());
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, detail)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
