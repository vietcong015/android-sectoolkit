package com.sectoolkit.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.sectoolkit.R;
import com.sectoolkit.intent.IntentDispatcher;
import com.sectoolkit.model.IntentExtra;
import com.sectoolkit.ui.adapters.ExtrasAdapter;

import java.util.ArrayList;
import java.util.List;

public class IntentLabFragment extends Fragment {

    private TextInputEditText packageInput;
    private TextInputEditText classInput;
    private TextInputEditText actionInput;
    private MaterialButtonToggleGroup modeToggle;
    private RecyclerView extrasRecycler;
    private ExtrasAdapter extrasAdapter;
    private final List<IntentExtra> extrasList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_intent_lab, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        packageInput = view.findViewById(R.id.input_package);
        classInput = view.findViewById(R.id.input_class);
        actionInput = view.findViewById(R.id.input_action);
        modeToggle = view.findViewById(R.id.mode_toggle);
        extrasRecycler = view.findViewById(R.id.recycler_extras);
        MaterialButton addExtraBtn = view.findViewById(R.id.btn_add_extra);
        MaterialButton dispatchBtn = view.findViewById(R.id.btn_dispatch);

        extrasAdapter = new ExtrasAdapter(extrasList);
        extrasRecycler.setLayoutManager(new LinearLayoutManager(getContext()));
        extrasRecycler.setAdapter(extrasAdapter);

        addExtraBtn.setOnClickListener(v -> addNewExtra());
        dispatchBtn.setOnClickListener(v -> dispatchIntent());
    }

    private void addNewExtra() {
        extrasList.add(new IntentExtra("", "", IntentExtra.ExtraType.STRING));
        extrasAdapter.notifyItemInserted(extrasList.size() - 1);
    }

    private void dispatchIntent() {
        String pkg = packageInput.getText() != null ? packageInput.getText().toString().trim() : "";
        String cls = classInput.getText() != null ? classInput.getText().toString().trim() : "";
        String action = actionInput.getText() != null ? actionInput.getText().toString().trim() : "";

        if (pkg.isEmpty() && action.isEmpty()) {
            Toast.makeText(getContext(), "Enter at least a Package Name or Action", Toast.LENGTH_SHORT).show();
            return;
        }

        IntentDispatcher.DispatchMode mode = getSelectedMode();

        IntentDispatcher.getInstance().dispatch(
                requireContext(), pkg, cls, action, new ArrayList<>(extrasList), mode,
                new IntentDispatcher.DispatchCallback() {
                    @Override
                    public void onSuccess(String message) {
                        requireActivity().runOnUiThread(() ->
                                Toast.makeText(getContext(), "✓ " + message, Toast.LENGTH_SHORT).show());
                    }

                    @Override
                    public void onFailure(String error) {
                        requireActivity().runOnUiThread(() ->
                                Toast.makeText(getContext(), "✗ " + error, Toast.LENGTH_LONG).show());
                    }
                }
        );
    }

    private IntentDispatcher.DispatchMode getSelectedMode() {
        int checkedId = modeToggle.getCheckedButtonId();
        if (checkedId == R.id.btn_mode_service) return IntentDispatcher.DispatchMode.SERVICE;
        if (checkedId == R.id.btn_mode_broadcast) return IntentDispatcher.DispatchMode.BROADCAST;
        return IntentDispatcher.DispatchMode.ACTIVITY;
    }
}
