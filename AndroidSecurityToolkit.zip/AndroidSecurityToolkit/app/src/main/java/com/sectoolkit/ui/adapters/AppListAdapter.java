package com.sectoolkit.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.sectoolkit.R;
import com.sectoolkit.model.AppInfo;

import java.util.List;

public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.AppViewHolder> {

    public interface OnAppClickListener {
        void onAppClick(AppInfo appInfo);
    }

    private List<AppInfo> apps;
    private final OnAppClickListener listener;

    public AppListAdapter(List<AppInfo> apps, OnAppClickListener listener) {
        this.apps = apps;
        this.listener = listener;
    }

    public void updateData(List<AppInfo> newApps) {
        this.apps = newApps;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public AppViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_app, parent, false);
        return new AppViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AppViewHolder holder, int position) {
        AppInfo app = apps.get(position);
        holder.bind(app, listener);
    }

    @Override
    public int getItemCount() { return apps.size(); }

    static class AppViewHolder extends RecyclerView.ViewHolder {
        private final ImageView iconView;
        private final TextView nameText;
        private final TextView packageText;
        private final Chip exportedChip;

        AppViewHolder(@NonNull View itemView) {
            super(itemView);
            iconView = itemView.findViewById(R.id.app_icon);
            nameText = itemView.findViewById(R.id.app_name);
            packageText = itemView.findViewById(R.id.package_name);
            exportedChip = itemView.findViewById(R.id.exported_chip);
        }

        void bind(AppInfo app, OnAppClickListener listener) {
            iconView.setImageDrawable(app.getIcon());
            nameText.setText(app.getAppName());
            packageText.setText(app.getPackageName());

            int count = app.getExportedComponentCount();
            exportedChip.setText(count + " exported");
            exportedChip.setChipBackgroundColorResource(
                    count > 0 ? R.color.chip_warning : R.color.chip_safe);

            itemView.setOnClickListener(v -> listener.onAppClick(app));
        }
    }
}
