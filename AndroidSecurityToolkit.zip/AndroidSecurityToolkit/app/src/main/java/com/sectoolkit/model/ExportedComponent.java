package com.sectoolkit.model;

public class ExportedComponent {

    public enum ComponentType {
        ACTIVITY, SERVICE, RECEIVER, PROVIDER
    }

    private final String className;
    private final ComponentType type;
    private final boolean hasPermission;
    private final String permission;

    public ExportedComponent(String className, ComponentType type, boolean hasPermission, String permission) {
        this.className = className;
        this.type = type;
        this.hasPermission = hasPermission;
        this.permission = permission;
    }

    public String getClassName() { return className; }
    public ComponentType getType() { return type; }
    public boolean isHasPermission() { return hasPermission; }
    public String getPermission() { return permission; }

    public String getSimpleClassName() {
        if (className == null) return "Unknown";
        int lastDot = className.lastIndexOf('.');
        return lastDot >= 0 ? className.substring(lastDot + 1) : className;
    }
}
