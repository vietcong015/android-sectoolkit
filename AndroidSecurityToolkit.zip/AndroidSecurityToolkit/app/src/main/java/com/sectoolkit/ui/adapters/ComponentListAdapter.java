package com.sectoolkit.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.sectoolkit.R;
import com.sectoolkit.model.ExportedComponent;

import java.util.List;

public class ComponentListAdapter extends RecyclerView.Adapter<ComponentListAdapter.ComponentViewHolder> {

    private final List<ExportedComponent> components;

    public ComponentListAdapter(List<ExportedComponent> components) {
        this.components = components;
    }

    @NonNull
    @Override
    public ComponentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_component, parent, false);
        return new ComponentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ComponentViewHolder holder, int position) {
        holder.bind(components.get(position));
    }

    @Override
    public int getItemCount() { return components.size(); }

    static class ComponentViewHolder extends RecyclerView.ViewHolder {
        private final TextView classNameText;
        private final Chip typeChip;
        private final Chip permissionChip;
        private final TextView permissionText;

        ComponentViewHolder(@NonNull View itemView) {
            super(itemView);
            classNameText = itemView.findViewById(R.id.class_name);
            typeChip = itemView.findViewById(R.id.type_chip);
            permissionChip = itemView.findViewById(R.id.permission_chip);
            permissionText = itemView.findViewById(R.id.permission_text);
        }

        void bind(ExportedComponent component) {
            classNameText.setText(component.getSimpleClassName());

            typeChip.setText(component.getType().name());
            int typeColor;
            switch (component.getType()) {
                case ACTIVITY: typeColor = R.color.type_activity; break;
                case SERVICE:  typeColor = R.color.type_service;  break;
                case RECEIVER: typeColor = R.color.type_receiver; break;
                case PROVIDER: typeColor = R.color.type_provider; break;
                default:       typeColor = R.color.type_activity; break;
            }
            typeChip.setChipBackgroundColorResource(typeColor);

            if (component.isHasPermission()) {
                permissionChip.setText("PROTECTED");
                permissionChip.setChipBackgroundColorResource(R.color.chip_safe);
                permissionText.setText(component.getPermission());
                permissionText.setVisibility(View.VISIBLE);
            } else {
                permissionChip.setText("NO PERMISSION");
                permissionChip.setChipBackgroundColorResource(R.color.chip_danger);
                permissionText.setVisibility(View.GONE);
            }
        }
    }
}
