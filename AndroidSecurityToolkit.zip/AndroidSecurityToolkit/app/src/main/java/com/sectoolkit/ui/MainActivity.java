package com.sectoolkit.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.sectoolkit.R;
import com.sectoolkit.ui.fragments.ClipboardFragment;
import com.sectoolkit.ui.fragments.IntentLabFragment;
import com.sectoolkit.ui.fragments.ProviderAuditorFragment;
import com.sectoolkit.ui.fragments.ReconFragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navView = findViewById(R.id.bottom_navigation);

        if (savedInstanceState == null) {
            loadFragment(new ReconFragment());
        }

        navView.setOnItemSelectedListener(item -> {
            Fragment selected = null;
            int id = item.getItemId();
            if (id == R.id.nav_recon) {
                selected = new ReconFragment();
            } else if (id == R.id.nav_intent) {
                selected = new IntentLabFragment();
            } else if (id == R.id.nav_provider) {
                selected = new ProviderAuditorFragment();
            } else if (id == R.id.nav_clipboard) {
                selected = new ClipboardFragment();
            }
            if (selected != null) {
                loadFragment(selected);
                return true;
            }
            return false;
        });
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
