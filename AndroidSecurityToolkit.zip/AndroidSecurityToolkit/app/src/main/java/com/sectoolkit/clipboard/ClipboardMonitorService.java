package com.sectoolkit.clipboard;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import com.sectoolkit.model.ClipboardEntry;

import java.util.ArrayList;
import java.util.List;

public class ClipboardMonitorService extends Service {

    private static final String CHANNEL_ID = "clipboard_monitor_channel";
    private static final int NOTIFICATION_ID = 1001;

    private ClipboardManager clipboardManager;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private static final List<ClipboardEntry> capturedEntries = new ArrayList<>();
    private static ClipboardEventListener eventListener;

    public interface ClipboardEventListener {
        void onNewClipboardEntry(ClipboardEntry entry);
    }

    public static void setEventListener(ClipboardEventListener listener) {
        eventListener = listener;
    }

    public static List<ClipboardEntry> getCapturedEntries() {
        return new ArrayList<>(capturedEntries);
    }

    public static void clearEntries() {
        capturedEntries.clear();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipListener = this::handleClipboardChange;
        clipboardManager.addPrimaryClipChangedListener(clipListener);
        startForeground(NOTIFICATION_ID, buildNotification());
    }

    private void handleClipboardChange() {
        try {
            if (clipboardManager.hasPrimaryClip() && clipboardManager.getPrimaryClip() != null) {
                android.content.ClipData.Item item = clipboardManager.getPrimaryClip().getItemAt(0);
                if (item != null && item.getText() != null) {
                    String text = item.getText().toString();
                    if (!text.isEmpty()) {
                        ClipboardEntry entry = new ClipboardEntry(text, System.currentTimeMillis());
                        capturedEntries.add(0, entry);
                        if (eventListener != null) {
                            eventListener.onNewClipboardEntry(entry);
                        }
                    }
                }
            }
        } catch (SecurityException ignored) {
        } catch (Exception ignored) {
        }
    }

    private Notification buildNotification() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Clipboard Monitor",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Monitoring clipboard for security audit");
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Security Toolkit")
                .setContentText("Clipboard monitor active")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (clipboardManager != null && clipListener != null) {
            clipboardManager.removePrimaryClipChangedListener(clipListener);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
