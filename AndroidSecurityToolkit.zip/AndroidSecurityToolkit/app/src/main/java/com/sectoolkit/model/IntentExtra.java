package com.sectoolkit.model;

public class IntentExtra {
    public enum ExtraType { STRING, INT, BOOLEAN, LONG, FLOAT }

    private String key;
    private String value;
    private ExtraType type;

    public IntentExtra(String key, String value, ExtraType type) {
        this.key = key;
        this.value = value;
        this.type = type;
    }

    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }
    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
    public ExtraType getType() { return type; }
    public void setType(ExtraType type) { this.type = type; }
}
