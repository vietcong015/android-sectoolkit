package com.sectoolkit.ui.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.android.material.textfield.TextInputEditText;
import com.sectoolkit.R;
import com.sectoolkit.provider.ContentProviderAuditor;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProviderAuditorFragment extends Fragment {

    private TextInputEditText uriInput;
    private LinearLayout resultContainer;
    private ScrollView scrollView;
    private CircularProgressIndicator progressIndicator;
    private TextView statusText;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_provider_auditor, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        uriInput = view.findViewById(R.id.input_uri);
        resultContainer = view.findViewById(R.id.result_container);
        scrollView = view.findViewById(R.id.scroll_view);
        progressIndicator = view.findViewById(R.id.progress_indicator);
        statusText = view.findViewById(R.id.status_text);
        MaterialButton queryBtn = view.findViewById(R.id.btn_query);

        queryBtn.setOnClickListener(v -> executeQuery());
    }

    private void executeQuery() {
        String uri = uriInput.getText() != null ? uriInput.getText().toString().trim() : "";
        if (uri.isEmpty()) return;

        resultContainer.removeAllViews();
        progressIndicator.setVisibility(View.VISIBLE);
        statusText.setText("Querying provider...");

        executor.execute(() -> {
            ContentProviderAuditor.QueryResult result =
                    ContentProviderAuditor.getInstance(requireContext()).query(uri);

            mainHandler.post(() -> {
                progressIndicator.setVisibility(View.GONE);
                displayResult(result);
            });
        });
    }

    private void displayResult(ContentProviderAuditor.QueryResult result) {
        resultContainer.removeAllViews();

        if (!result.isSuccess()) {
            statusText.setText("Query failed");
            addTextRow("ERROR: " + result.getErrorMessage(), true);
            return;
        }

        int rowCount = result.getRows().size();
        statusText.setText(rowCount + " rows returned • " + result.getColumns().size() + " columns");

        if (rowCount == 0) {
            addTextRow("No rows returned from provider", false);
            return;
        }

        addHeaderRow(result.getColumns());
        for (Map<String, String> row : result.getRows()) {
            addDataRow(row, result.getColumns());
        }
    }

    private void addHeaderRow(List<String> columns) {
        StringBuilder sb = new StringBuilder();
        for (String col : columns) {
            sb.append(String.format("%-20s", col)).append("  ");
        }
        TextView tv = new TextView(getContext());
        tv.setText(sb.toString());
        tv.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_LabelMedium);
        tv.setPadding(16, 8, 16, 8);
        tv.setBackgroundResource(R.color.header_bg);
        resultContainer.addView(tv);
    }

    private void addDataRow(Map<String, String> row, List<String> columns) {
        StringBuilder sb = new StringBuilder();
        for (String col : columns) {
            String val = row.getOrDefault(col, "");
            sb.append(String.format("%-20s", val != null ? val : "null")).append("  ");
        }
        TextView tv = new TextView(getContext());
        tv.setText(sb.toString());
        tv.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodySmall);
        tv.setPadding(16, 6, 16, 6);
        resultContainer.addView(tv);

        View divider = new View(getContext());
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1));
        divider.setBackgroundResource(R.color.divider_color);
        resultContainer.addView(divider);
    }

    private void addTextRow(String text, boolean isError) {
        TextView tv = new TextView(getContext());
        tv.setText(text);
        tv.setPadding(16, 12, 16, 12);
        if (isError) {
            tv.setTextColor(requireContext().getColor(R.color.error_color));
        }
        resultContainer.addView(tv);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
