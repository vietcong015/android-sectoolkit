package com.sectoolkit.ui.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sectoolkit.R;
import com.sectoolkit.model.ExportedComponent;
import com.sectoolkit.recon.ExportedComponentScanner;
import com.sectoolkit.ui.adapters.ComponentListAdapter;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ComponentDetailFragment extends Fragment {

    private static final String ARG_PACKAGE = "package_name";
    private static final String ARG_APP_NAME = "app_name";

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView headerText;
    private TextView emptyText;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public static ComponentDetailFragment newInstance(String packageName, String appName) {
        ComponentDetailFragment fragment = new ComponentDetailFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PACKAGE, packageName);
        args.putString(ARG_APP_NAME, appName);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_component_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recycler_components);
        progressBar = view.findViewById(R.id.progress_bar);
        headerText = view.findViewById(R.id.header_text);
        emptyText = view.findViewById(R.id.empty_text);

        String packageName = getArguments() != null ? getArguments().getString(ARG_PACKAGE) : "";
        String appName = getArguments() != null ? getArguments().getString(ARG_APP_NAME) : "";

        headerText.setText(appName + "\n" + packageName);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        executor.execute(() -> {
            List<ExportedComponent> components = ExportedComponentScanner
                    .getInstance(requireContext())
                    .getExportedComponents(packageName);

            mainHandler.post(() -> {
                progressBar.setVisibility(View.GONE);
                if (components.isEmpty()) {
                    emptyText.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                } else {
                    emptyText.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                    recyclerView.setAdapter(new ComponentListAdapter(components));
                }
            });
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
