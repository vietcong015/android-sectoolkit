package com.sectoolkit.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ClipboardEntry {
    private final String content;
    private final long timestamp;
    private static final SimpleDateFormat DATE_FORMAT =
            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

    public ClipboardEntry(String content, long timestamp) {
        this.content = content;
        this.timestamp = timestamp;
    }

    public String getContent() { return content; }
    public long getTimestamp() { return timestamp; }

    public String getFormattedTime() {
        return DATE_FORMAT.format(new Date(timestamp));
    }
}
