package com.sectoolkit.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.sectoolkit.R;
import com.sectoolkit.model.IntentExtra;

import java.util.List;

public class ExtrasAdapter extends RecyclerView.Adapter<ExtrasAdapter.ExtraViewHolder> {

    private final List<IntentExtra> extras;

    public ExtrasAdapter(List<IntentExtra> extras) {
        this.extras = extras;
    }

    @NonNull
    @Override
    public ExtraViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_intent_extra, parent, false);
        return new ExtraViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExtraViewHolder holder, int position) {
        holder.bind(extras.get(position), position);
    }

    @Override
    public int getItemCount() { return extras.size(); }

    class ExtraViewHolder extends RecyclerView.ViewHolder {
        private final TextInputEditText keyInput;
        private final TextInputEditText valueInput;
        private final Spinner typeSpinner;
        private final MaterialButton removeBtn;

        ExtraViewHolder(@NonNull View itemView) {
            super(itemView);
            keyInput = itemView.findViewById(R.id.extra_key);
            valueInput = itemView.findViewById(R.id.extra_value);
            typeSpinner = itemView.findViewById(R.id.extra_type_spinner);
            removeBtn = itemView.findViewById(R.id.btn_remove_extra);
        }

        void bind(IntentExtra extra, int position) {
            String[] types = {"STRING", "INT", "BOOLEAN", "LONG", "FLOAT"};
            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                    itemView.getContext(),
                    android.R.layout.simple_spinner_item,
                    types
            );
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            typeSpinner.setAdapter(spinnerAdapter);
            typeSpinner.setSelection(extra.getType().ordinal());

            if (extra.getKey() != null) keyInput.setText(extra.getKey());
            if (extra.getValue() != null) valueInput.setText(extra.getValue());

            keyInput.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus && keyInput.getText() != null) {
                    extra.setKey(keyInput.getText().toString());
                }
            });

            valueInput.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus && valueInput.getText() != null) {
                    extra.setValue(valueInput.getText().toString());
                }
            });

            typeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                    extra.setType(IntentExtra.ExtraType.values()[pos]);
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });

            removeBtn.setOnClickListener(v -> {
                int adapterPosition = getAdapterPosition();
                if (adapterPosition != RecyclerView.NO_ID) {
                    extras.remove(adapterPosition);
                    notifyItemRemoved(adapterPosition);
                }
            });
        }
    }
}
