package com.sectoolkit.intent;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

import com.sectoolkit.model.IntentExtra;

import java.util.List;

public class IntentDispatcher {

    public enum DispatchMode { ACTIVITY, SERVICE, BROADCAST }

    public interface DispatchCallback {
        void onSuccess(String message);
        void onFailure(String error);
    }

    private static IntentDispatcher instance;

    private IntentDispatcher() {}

    public static synchronized IntentDispatcher getInstance() {
        if (instance == null) {
            instance = new IntentDispatcher();
        }
        return instance;
    }

    public void dispatch(Context context, String packageName, String className,
                         String action, List<IntentExtra> extras,
                         DispatchMode mode, DispatchCallback callback) {
        try {
            Intent intent = buildIntent(packageName, className, action, extras);
            switch (mode) {
                case ACTIVITY:
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    callback.onSuccess("Activity started successfully");
                    break;
                case SERVICE:
                    context.startService(intent);
                    callback.onSuccess("Service started successfully");
                    break;
                case BROADCAST:
                    context.sendBroadcast(intent);
                    callback.onSuccess("Broadcast sent successfully");
                    break;
            }
        } catch (SecurityException e) {
            callback.onFailure("SecurityException: " + e.getMessage());
        } catch (Exception e) {
            callback.onFailure("Error: " + e.getMessage());
        }
    }

    private Intent buildIntent(String packageName, String className,
                                String action, List<IntentExtra> extras) {
        Intent intent = new Intent();

        if (!packageName.isEmpty() && !className.isEmpty()) {
            intent.setComponent(new ComponentName(packageName, className));
        } else if (!packageName.isEmpty()) {
            intent.setPackage(packageName);
        }

        if (!action.isEmpty()) {
            intent.setAction(action);
        }

        if (extras != null) {
            for (IntentExtra extra : extras) {
                applyExtra(intent, extra);
            }
        }

        return intent;
    }

    private void applyExtra(Intent intent, IntentExtra extra) {
        if (extra.getKey() == null || extra.getKey().isEmpty()) return;
        try {
            switch (extra.getType()) {
                case STRING:
                    intent.putExtra(extra.getKey(), extra.getValue());
                    break;
                case INT:
                    intent.putExtra(extra.getKey(), Integer.parseInt(extra.getValue()));
                    break;
                case BOOLEAN:
                    intent.putExtra(extra.getKey(), Boolean.parseBoolean(extra.getValue()));
                    break;
                case LONG:
                    intent.putExtra(extra.getKey(), Long.parseLong(extra.getValue()));
                    break;
                case FLOAT:
                    intent.putExtra(extra.getKey(), Float.parseFloat(extra.getValue()));
                    break;
            }
        } catch (NumberFormatException ignored) {
        }
    }
}
