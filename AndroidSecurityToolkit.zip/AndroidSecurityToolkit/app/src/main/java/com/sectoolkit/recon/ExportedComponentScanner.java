package com.sectoolkit.recon;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;

import com.sectoolkit.model.AppInfo;
import com.sectoolkit.model.ExportedComponent;

import java.util.ArrayList;
import java.util.List;

public class ExportedComponentScanner {

    private static ExportedComponentScanner instance;
    private final PackageManager packageManager;

    private ExportedComponentScanner(Context context) {
        this.packageManager = context.getApplicationContext().getPackageManager();
    }

    public static synchronized ExportedComponentScanner getInstance(Context context) {
        if (instance == null) {
            instance = new ExportedComponentScanner(context);
        }
        return instance;
    }

    public List<AppInfo> getAllInstalledApps() {
        List<AppInfo> apps = new ArrayList<>();
        List<PackageInfo> packages = packageManager.getInstalledPackages(
                PackageManager.GET_ACTIVITIES |
                PackageManager.GET_SERVICES |
                PackageManager.GET_RECEIVERS |
                PackageManager.GET_PROVIDERS
        );

        for (PackageInfo pkg : packages) {
            try {
                int exportedCount = countExportedComponents(pkg);
                String appName = pkg.applicationInfo.loadLabel(packageManager).toString();
                apps.add(new AppInfo(
                        pkg.packageName,
                        appName,
                        pkg.applicationInfo.loadIcon(packageManager),
                        exportedCount
                ));
            } catch (Exception ignored) {
            }
        }
        return apps;
    }

    private int countExportedComponents(PackageInfo pkg) {
        int count = 0;
        if (pkg.activities != null) {
            for (ActivityInfo a : pkg.activities) if (a.exported) count++;
        }
        if (pkg.services != null) {
            for (ServiceInfo s : pkg.services) if (s.exported) count++;
        }
        if (pkg.receivers != null) {
            for (ActivityInfo r : pkg.receivers) if (r.exported) count++;
        }
        if (pkg.providers != null) {
            for (ProviderInfo p : pkg.providers) if (p.exported) count++;
        }
        return count;
    }

    public List<ExportedComponent> getExportedComponents(String packageName) {
        List<ExportedComponent> components = new ArrayList<>();
        try {
            PackageInfo pkg = packageManager.getPackageInfo(
                    packageName,
                    PackageManager.GET_ACTIVITIES |
                    PackageManager.GET_SERVICES |
                    PackageManager.GET_RECEIVERS |
                    PackageManager.GET_PROVIDERS
            );

            if (pkg.activities != null) {
                for (ActivityInfo info : pkg.activities) {
                    if (info.exported) {
                        components.add(new ExportedComponent(
                                info.name,
                                ExportedComponent.ComponentType.ACTIVITY,
                                info.permission != null,
                                info.permission
                        ));
                    }
                }
            }

            if (pkg.services != null) {
                for (ServiceInfo info : pkg.services) {
                    if (info.exported) {
                        components.add(new ExportedComponent(
                                info.name,
                                ExportedComponent.ComponentType.SERVICE,
                                info.permission != null,
                                info.permission
                        ));
                    }
                }
            }

            if (pkg.receivers != null) {
                for (ActivityInfo info : pkg.receivers) {
                    if (info.exported) {
                        components.add(new ExportedComponent(
                                info.name,
                                ExportedComponent.ComponentType.RECEIVER,
                                info.permission != null,
                                info.permission
                        ));
                    }
                }
            }

            if (pkg.providers != null) {
                for (ProviderInfo info : pkg.providers) {
                    if (info.exported) {
                        String perm = info.readPermission != null ? info.readPermission : info.writePermission;
                        components.add(new ExportedComponent(
                                info.name,
                                ExportedComponent.ComponentType.PROVIDER,
                                perm != null,
                                perm
                        ));
                    }
                }
            }

        } catch (PackageManager.NameNotFoundException ignored) {
        }
        return components;
    }
}
