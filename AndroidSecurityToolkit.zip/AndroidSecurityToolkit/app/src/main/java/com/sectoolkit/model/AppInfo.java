package com.sectoolkit.model;

import android.graphics.drawable.Drawable;

public class AppInfo {
    private final String packageName;
    private final String appName;
    private final Drawable icon;
    private final int exportedComponentCount;

    public AppInfo(String packageName, String appName, Drawable icon, int exportedComponentCount) {
        this.packageName = packageName;
        this.appName = appName;
        this.icon = icon;
        this.exportedComponentCount = exportedComponentCount;
    }

    public String getPackageName() { return packageName; }
    public String getAppName() { return appName; }
    public Drawable getIcon() { return icon; }
    public int getExportedComponentCount() { return exportedComponentCount; }
}
