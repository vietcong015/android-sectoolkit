package com.sectoolkit.ui.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.sectoolkit.R;
import com.sectoolkit.clipboard.ClipboardMonitorService;
import com.sectoolkit.model.ClipboardEntry;
import com.sectoolkit.ui.adapters.ClipboardAdapter;

import java.util.ArrayList;
import java.util.List;

public class ClipboardFragment extends Fragment implements ClipboardMonitorService.ClipboardEventListener {

    private SwitchMaterial monitorSwitch;
    private RecyclerView recyclerView;
    private ClipboardAdapter adapter;
    private TextView entryCountText;
    private TextView emptyText;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_clipboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        monitorSwitch = view.findViewById(R.id.switch_monitor);
        recyclerView = view.findViewById(R.id.recycler_clipboard);
        entryCountText = view.findViewById(R.id.entry_count_text);
        emptyText = view.findViewById(R.id.empty_text);
        MaterialButton clearBtn = view.findViewById(R.id.btn_clear);

        adapter = new ClipboardAdapter(new ArrayList<>());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        List<ClipboardEntry> existing = ClipboardMonitorService.getCapturedEntries();
        if (!existing.isEmpty()) {
            adapter.updateData(existing);
            updateCountDisplay(existing.size());
        }

        monitorSwitch.setOnCheckedChangeListener((btn, isChecked) -> {
            if (isChecked) {
                startMonitoring();
            } else {
                stopMonitoring();
            }
        });

        clearBtn.setOnClickListener(v -> {
            ClipboardMonitorService.clearEntries();
            adapter.updateData(new ArrayList<>());
            updateCountDisplay(0);
        });

        ClipboardMonitorService.setEventListener(this);
    }

    private void startMonitoring() {
        Intent serviceIntent = new Intent(getContext(), ClipboardMonitorService.class);
        requireContext().startForegroundService(serviceIntent);
    }

    private void stopMonitoring() {
        Intent serviceIntent = new Intent(getContext(), ClipboardMonitorService.class);
        requireContext().stopService(serviceIntent);
    }

    @Override
    public void onNewClipboardEntry(ClipboardEntry entry) {
        requireActivity().runOnUiThread(() -> {
            List<ClipboardEntry> current = ClipboardMonitorService.getCapturedEntries();
            adapter.updateData(current);
            updateCountDisplay(current.size());
            recyclerView.scrollToPosition(0);
        });
    }

    private void updateCountDisplay(int count) {
        entryCountText.setText(count + " entries captured");
        emptyText.setVisibility(count == 0 ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(count == 0 ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ClipboardMonitorService.setEventListener(null);
    }
}
