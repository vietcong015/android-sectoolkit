package com.sectoolkit.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sectoolkit.R;
import com.sectoolkit.model.ClipboardEntry;

import java.util.List;

public class ClipboardAdapter extends RecyclerView.Adapter<ClipboardAdapter.ClipViewHolder> {

    private List<ClipboardEntry> entries;

    public ClipboardAdapter(List<ClipboardEntry> entries) {
        this.entries = entries;
    }

    public void updateData(List<ClipboardEntry> newEntries) {
        this.entries = newEntries;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ClipViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_clipboard_entry, parent, false);
        return new ClipViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ClipViewHolder holder, int position) {
        holder.bind(entries.get(position));
    }

    @Override
    public int getItemCount() { return entries.size(); }

    static class ClipViewHolder extends RecyclerView.ViewHolder {
        private final TextView contentText;
        private final TextView timestampText;
        private final TextView indexText;

        ClipViewHolder(@NonNull View itemView) {
            super(itemView);
            contentText = itemView.findViewById(R.id.clip_content);
            timestampText = itemView.findViewById(R.id.clip_timestamp);
            indexText = itemView.findViewById(R.id.clip_index);
        }

        void bind(ClipboardEntry entry) {
            contentText.setText(entry.getContent());
            timestampText.setText(entry.getFormattedTime());
            indexText.setText(String.valueOf(getAdapterPosition() + 1));
        }
    }
}
