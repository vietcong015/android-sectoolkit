package com.sectoolkit.provider;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ContentProviderAuditor {

    public static class QueryResult {
        private final List<String> columns;
        private final List<Map<String, String>> rows;
        private final String errorMessage;
        private final boolean success;

        private QueryResult(List<String> columns, List<Map<String, String>> rows) {
            this.columns = columns;
            this.rows = rows;
            this.errorMessage = null;
            this.success = true;
        }

        private QueryResult(String errorMessage) {
            this.columns = new ArrayList<>();
            this.rows = new ArrayList<>();
            this.errorMessage = errorMessage;
            this.success = false;
        }

        public List<String> getColumns() { return columns; }
        public List<Map<String, String>> getRows() { return rows; }
        public String getErrorMessage() { return errorMessage; }
        public boolean isSuccess() { return success; }
    }

    private static ContentProviderAuditor instance;
    private final Context context;

    private ContentProviderAuditor(Context context) {
        this.context = context.getApplicationContext();
    }

    public static synchronized ContentProviderAuditor getInstance(Context context) {
        if (instance == null) {
            instance = new ContentProviderAuditor(context);
        }
        return instance;
    }

    public QueryResult query(String uriString) {
        if (uriString == null || uriString.trim().isEmpty()) {
            return new QueryResult("URI cannot be empty");
        }

        Uri uri;
        try {
            uri = Uri.parse(uriString.trim());
        } catch (Exception e) {
            return new QueryResult("Invalid URI format: " + e.getMessage());
        }

        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(uri, null, null, null, null);

            if (cursor == null) {
                return new QueryResult("Query returned null cursor. Provider may not exist or access denied.");
            }

            List<String> columns = new ArrayList<>();
            for (String col : cursor.getColumnNames()) {
                columns.add(col);
            }

            List<Map<String, String>> rows = new ArrayList<>();
            while (cursor.moveToNext()) {
                Map<String, String> row = new LinkedHashMap<>();
                for (int i = 0; i < cursor.getColumnCount(); i++) {
                    String colName = cursor.getColumnName(i);
                    String value;
                    try {
                        value = cursor.getString(i);
                        if (value == null) value = "[NULL]";
                    } catch (Exception e) {
                        value = "[UNREADABLE]";
                    }
                    row.put(colName, value);
                }
                rows.add(row);
            }

            return new QueryResult(columns, rows);

        } catch (SecurityException e) {
            return new QueryResult("SecurityException: Permission denied — " + e.getMessage());
        } catch (IllegalArgumentException e) {
            return new QueryResult("IllegalArgumentException: " + e.getMessage());
        } catch (Exception e) {
            return new QueryResult("Unexpected error: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
}
